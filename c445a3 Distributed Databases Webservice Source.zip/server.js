//import node dependencies
var express = require("express");
var fileSystem = require('fs');
var path = require("path");
var bodyParser = require("body-parser");
var request = require('request');
var mongodb = require("mongodb");


/************************START UTIL METHODS*******************/
/************************START UTIL METHODS*******************/

//checks if a value is a number
function isNumber(n) {
  return !isNaN(parseFloat(n)) && isFinite(n);
}

//define String.contains convenience method
String.prototype.contains = function(it) { return this.indexOf(it) > -1}

/**
 * Returns a random number between min (inclusive) and max (exclusive)
 */
function getRandomIntEx(min, max) {
    return Math.floor(Math.random() * (max - min)) + min;
}

/**
 * Returns a random integer between min (inclusive) and max (inclusive)
 * Using Math.round() will give you a non-uniform distribution!
 */
function getRandomIntIn(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

/**
 * A simple console log handler.
 * @param origin: the origin of this console log. Where is it coming from.
 * @param data: the data to be logged to the console.
 * Both params are required to log
 */
function consoleLog(origin, data, isError){
	var date = new Date();
	var errorLabel = isError && isError == true? "[ERROR]": "";
	if(origin && data) console.log("[" + origin + "]" + errorLabel + "[" + date + "]:: " + data);
	else console.log("[unknownOrigin]" + errorLabel + "[" + date + "]:: " + data);
}

/************************END UTIL METHODS*******************/
/************************END UTIL METHODS*******************/

//for mongodb
var ObjectID = mongodb.ObjectID;

/* PUBLICATIONS SCHEMA:

{
  "_id": <ObjectId>
  //AND OTHER DATA FROM Medium.com
}
*/
var LOGS_COLLECTION = "logs";
var COUNTERS_COLLECTION = "counters";

var app = express();
//create the path to the public files
app.use(express.static(__dirname + "/public"));
app.use(bodyParser.json());

/*Create a database variable outside of the 
database connection callback 
to reuse the connection pool in your app.*/
var dbs = [];

var getDbByServerId = function(serverId) {
	return dbs[serverId];
}

var dbConxCallback = function(err, database) {
	var count
	if(err) {
		consoleLog("dbConxCallback", err.message);
		process.exit(1);
	}

	//save the database object from the callback to our global db var for reuse
	dbs.push(database);
	//close on the current length of the dbs array as the current db's id
	var dbId = (function(dbs){return dbs.length - 1})(dbs);

	//start 2nd server db
	if(dbId == 0) mongodb.MongoClient.connect(process.env.MONGOLAB_BLACK_URI, dbConxCallback);
	//start 3rd server db
	else if(dbId == 1) mongodb.MongoClient.connect(process.env.MONGOLAB_PURPLE_URI, dbConxCallback);
	//start 4th server db
	else if(dbId == 2) mongodb.MongoClient.connect(process.env.MONGOLAB_ROSE_URI, dbConxCallback);
	//start 5th server db
	else if(dbId == 3) mongodb.MongoClient.connect(process.env.MONGOLAB_WHITE_URI, dbConxCallback);

	//add the first logIndex to the database as 0.
	findOneByAndRun(database, COUNTERS_COLLECTION, 
		{}, 
		function(doc) {
			consoleLog("dbConxCallback", "logIndex sequence number for server db #" + dbId + " exists: seq = " + doc.seq);
		},
		//if an error arises, its likely cause the doc was not found. 
		function() {
			//insert the first logIndex to the database as 0.
			database.collection(COUNTERS_COLLECTION).insert(
			   {
			      _id: "logIndex",
			      seq: 0
			   }
			);
		}, 
		false
	);

	//runDebuggingFunctions(database);

	consoleLog("dbConxCallback", "MongoDB for server #" + dbId + " connection ready");

	if(dbs.length == 5) {
		//init the app by listening on a designated port
		var server = app.listen(process.env.PORT || 8080, function() {
			var port = server.address().port;
			consoleLog("dbConxCallback", "All dbs connected. App now running on port " + port);
		});
		//server.timeout = 12 * 60 * 1000;
	}
}
/**
 *WARNING! USE WITH EXTREME CARE
 *
 */
function runDebuggingFunctions(db) {
	//for debugging purposes:
	dbClearCollection(db, LOGS_COLLECTION);
	dbClearCollection(db, COUNTERS_COLLECTION);
}

/**
 *WARNING! USE WITH EXTREME CARE
 *setValue must look something like {fieldName:1}
 */
function dbRemoveCollectionDocumentsBy(db, collectionName, query) {
	if(db && collectionName && query) {
		consoleLog("dbRemoveCollectionDocumentsBy", "Setting db collection field: " + collectionName + " " + query);
		db.collection(collectionName).remove(query);
	}
}

/**
 *WARNING! USE WITH EXTREME CARE
 *setValue must look something like {fieldName:1}
 */
function dbRemoveOneCollectionDocumentBy(db, collectionName, query) {
	if(db && collectionName && query) {
		consoleLog("dbRemoveOneCollectionDocumentBy", "Setting db collection field: " + collectionName + " " + query);
		db.collection(collectionName).remove(query, true);
	}
}

/**
 *WARNING! ONLY USE THIS METHOD FOR DEBUGGING PURPOSES
 */
function dbClearCollection(db, collectionName){
	if(db && collectionName) {
		db.collection(collectionName, function(err, collection){
		    collection.remove({},function(err, removed){});
		});
	}
}

function dbRemoveWhere(db, collectionName, query, callback, handleError){
	if(db && collectionName) {
		db.collection(collectionName, function(err, collection){
		    collection.remove(query,function(err, removed){
		    	if(err) {
		    		if(handleError) handleError(err);
		    	} else {
		    	    if(callback) callback(removed);
		    	}

		    });
		});
	}
}

/**
 *WARNING! USE WITH EXTREME CARE
 *setValue must look something like {fieldName:1}
 */
function dbSetCollectionField(db, collectionName, setValue) {
	if(db && collectionName && setValue) {
		consoleLog("dbSetCollectionField", "Setting db collection field: " + collectionName + " " + setValue);
		db.collection(collectionName).update({},
	        {$set : setValue},
	        {upsert:false,multi:true}
	    );
	}
}

/**
 *WARNING! USE WITH EXTREME CARE
 *unsetValue must look something like {fieldName:1}
 */
function dbUnsetCollectionField(db, collectionName, unsetValue) {
	if(db && collectionName && unsetValue) {
		consoleLog("dbUnsetCollectionField","Unsetting db collection field: " + collectionName + " " + unsetValue);
		db.collection(collectionName).update({},
	        {$unset : unsetValue},
	        {upsert:false,multi:true}
	    );
	}
}

function getNextRecordSequence(db, name, callback, handleError) {
	if(db) {
		consoleLog("getNextRecordSequence", "FINDING AND MODIFYING NEXT SEQ FOR " + name);
	   db.collection(COUNTERS_COLLECTION).findAndModify(
		    { _id: name },
		    [],
		    { $inc: { "seq": 1 } },
		    { upsert: true, new: true },
			function(err,doc) {
				// work here
				if(err || !doc) {
					consoleLog("getNextRecordSequence", "FAILED NEXT LOG INDEX: " 
					+ JSON.stringify(err));
					db.collection(COUNTERS_COLLECTION).insert(
					   {
					      _id: "logIndex",
					      seq: 0
					   }
					);
				} else {
					var nextLogIndex = doc.value.seq;
					consoleLog("getNextRecordSequence", "NEXT LOG INDEX = " + nextLogIndex);
					if(callback) callback(nextLogIndex);
				}
			}
		);
	} else {
		consoleLog("getNextRecordSequence", "NO DB PROVIDED!!!!!!");
		if(handleError) {
			handleError("No db provided.");
		}
	}
}

function updateSeq(db, name, newSeq, callback, handleError) {
	if(isNumber(newSeq)) {
		db.collection(COUNTERS_COLLECTION).updateOne(
			{ _id : name },
			{
				$set: { "seq": newSeq },
				$currentDate: { "lastModified": true }
			}, function(err, results) {
				consoleLog("updateSeq", results);
			}
		);

		if(callback) {
			callback();
		}
	} else {
		if(handleError) {
			handleError();
		}
	}
}

//start 1st server db
mongodb.MongoClient.connect(process.env.MONGODB_URI, dbConxCallback);



/**
 * Generic error handler used by all endpoints
 * HTTP response codes: 1xx -> Informational, 2xx -> Success, 3xx -> Redirection, 4xx Client Error, 5xx -> Server Error
 * http://www.restapitutorial.com/httpstatuscodes.html
 */
function handleError(res, reason, message, code) {
	consoleLog("handleError", "ERROR: " + reason + " || message: " + message, true);
	//set the response's status as the error code or default http 500 "internal server error"
	res.status(code || 500).json({"error": reason, "errorMessage": message});
}

/***************************START SOCKET COMMUNICATION**************************************/
//http://www.html5rocks.com/en/tutorials/frameworks/angular-websockets/
//https://github.com/btford/angular-socket-io-im/blob/master/app.js
/***************************START SOCKET COMMUNICATION**************************************/

// Socket.io Communication


/***************************END SOCKET COMMUNICATION**************************************/
/***************************END SOCKET COMMUNICATION**************************************/


/***************************START REST API ENDPOINTS**************************************/
//API ROUTES BELOW
/*these will allow us to expose data and 
data manipulation to our app users*/
/***************************START REST API ENDPOINTS**************************************/

/*****************************START PUBLICATIONS REQUESTS*******************/
/*****************************START PUBLICATIONS REQUESTS*******************/

function findOneByAndRun(db, collectionName, searchQuery, callback, handleError, showDebugMessages){
	if(db && searchQuery) {
		db.collection(collectionName).findOne(searchQuery,function(err, doc) {
			if(err || !doc) {
	    		//failed to find the corresponding log by id and contributorId. 
	    		//insert the new request
	    		if(!doc) {
	    			if(handleError) {
		    			if(showDebugMessages) consoleLog("findOneByAndRun", "Handling error as defined.")
		    			handleError(err);
		    		}
	    		}
	    		else if(err) {
	    			if(showDebugMessages) consoleLog("findOneByAndRun", "Failed to find one doc: " + err.message, true);
	    		}
			} else {
				//find succeeded
				//update the request
				if(showDebugMessages) consoleLog("findOneByAndRun", "FOUND ONE DOC. Running callback: " + JSON.stringify(doc));
				if(callback) callback(doc);
			}
		});
	}
}

function findByAndRun(db, collectionName, searchQuery, callback, handleError, showDebugMessages){
	if(db && searchQuery && callback) {
		db.collection(collectionName).find(searchQuery).sort( { createDate: -1 } ).toArray(function(err, doc) {
			if(err || !doc) {
	    		//failed to find the corresponding publication by id and contributorId. 
	    		//insert the new request
	    		if(err) {
	    			if(showDebugMessages) consoleLog("findByAndRun", "Failed to find one doc: " + err.message, true);
	    		}
	    		
	    		if(handleError) {
	    			if(showDebugMessages) consoleLog("findByAndRun", "Handling error as defined.")
	    			if(handleError) handleError(err);
	    		}
			} else {
				//find succeeded
				//update the request
				if(showDebugMessages) consoleLog("findByAndRun", "FOUND " + (doc? doc.length: 0) +  " DOCS. Running callback: " + JSON.stringify(doc));
				callback(doc);
			}
		});
	}
}

var allServersLogs = [];
var allServersLogsLastLength = 0;
function resetAllServerLogs() {
	allServersLogs = [];
	updateAllServerLogsLastLength();
}

function setAllServerLogs(logs) {
	allServersLogs = logs;
	updateAllServerLogsLastLength();
}

function updateAllServerLogsLastLength() {
	allServersLogsLastLength = allServersLogs.length;
}

function allServersLogsUpdated() {
	return allServersLogs.length != allServersLogsLastLength;
}

function getAllServerLogs(res, logs, completedServers, clientRefreshSecs, attempts) {
	function organizeCommentsUnderPictures(logs){
		var pictureLogs = [];
		for(var i = 0; i < logs.length; i++) {
			var currentLog = logs[i];
			
			if(currentLog.type.toLowerCase() === 'comment') {
				currentLog.independent = false;

				var relatedPictureLog = pictureLogs[currentLog.pid];
				var currentCommentLog = {index: currentLog.index, data: currentLog.data, createDate: currentLog.createDate}

				if(relatedPictureLog) {
					//consoleLog("organizeCommentsUnderPictures", currentLog.index + " RELATED PICTURE COMMENT LOGS EXISTS: " + currentLog.pid + " " + JSON.stringify(relatedPictureLog));
					//add this comment logs to its related picture's array of comment logs
					if(relatedPictureLog.commentLogs) {
						//the picture has created or claimed its comments array
						relatedPictureLog.commentLogs.push(currentCommentLog);
					} else {
						//the picture has not yet claimed its comments array which was created by another comment
						relatedPictureLog.push(currentCommentLog);
					}
					//consoleLog("organizeCommentsUnderPictures", currentLog.index + " ADDED TO RELATED PICTURE COMMENT LOGS: " + currentLog.pid + " " + JSON.stringify(relatedPictureLog));
				} else {
					//consoleLog("organizeCommentsUnderPictures", currentLog.index + " CREATING RELATED PICTURE COMMENT LOGS: " + currentLog.pid);
					//create new array for this comment's related picture to store its comments
					pictureLogs[currentLog.pid] = [currentCommentLog];
				}
			} else if(currentLog.type.toLowerCase() === 'picture') {
				currentLog.independent = true;

				var myCommentLogsArray = pictureLogs[currentLog.index];
				if(myCommentLogsArray) {
					//a comment already create this picture's comment logs array in the ma
					currentLog.commentLogs = myCommentLogsArray;
					//consoleLog("organizeCommentsUnderPictures", currentLog.index + " PICTURE COMMENT LOGS ALREADY EXISTS: " + JSON.stringify(myCommentLogsArray));
				} else {
					//create a new array for this picture to store its comment logs
					currentLog.commentLogs = [];
					//consoleLog("organizeCommentsUnderPictures", currentLog.index + " PICTURE CREATED COMMENT LOGS LOGS");
				}

				pictureLogs[currentLog.index] = currentLog;
			}
		}
		return pictureLogs;
	}

	if(allServersLogs.length == 0 || allServersLogsUpdated()) {
		consoleLog('getAllServerLogs', "All server logs updated or is empty. Recreating!")

	    for(var i = 0; i < dbs.length; i++) {
	        var serverId = i;
	        if (serverId !== null && serverId !== 'undefined') {
	            var db = getDbByServerId(serverId);

	            if (db) {
	                findByAndRun(db, LOGS_COLLECTION, {}, function (allLogs) {
	                	//found the server's logs
	                	var pictureLogs = organizeCommentsUnderPictures(allLogs);

	                    logs.push(pictureLogs);
	                    completedServers++;
	                    if(completedServers == dbs.length){
	                    	setAllServerLogs(logs);
	                        res.status(200).json({logs: logs, 'refreshSecs': clientRefreshSecs});
	                    }

	                }, function (err) {
	                    completedServers++;
	                    if(completedServers == dbs.length) {
	                        logs.errors.push("Failed to get logs for server #" + serverId)

	                        setAllServerLogs(logs);
	                        res.status(200).json({logs: logs, 'refreshSecs': clientRefreshSecs});
	                    }
	                });
	            } else {
	                completedServers++;
	                if(completedServers == dbs.length) {
	                    logs.errors.push("Failed to find a database for server #" + serverId)

	                    setAllServerLogs(logs);
	                    res.status(200).json({logs: logs, 'refreshSecs': clientRefreshSecs});
	                }
	            }
	        } else {
	            completedServers++;
	            if(completedServers == dbs.length) {
	                logs.errors.push("Failed to get logs for server #" + serverId + ". Invalid user input.")

	                setAllServerLogs(logs);
	                res.status(200).json({logs: logs, 'refreshSecs': clientRefreshSecs});
	            }
	        }
	    }
	} else {
		updateAllServerLogsLastLength();
		//consoleLog('getAllServerLogs', "Returning previous logs from allServersLogs")
		res.status(200).json({logs: allServersLogs, 'refreshSecs': clientRefreshSecs});
	}
}

function commitLog(res, serverId, logIndex, logData, logType, logPid, isLeader, imageFileName) {
	if(serverId && logIndex && logData) {
		//create the new log
		var newLog = {};
		newLog.serverId = serverId;
		//url decode log data for UTF-8 encoding
		if(logType.toLowerCase() === "picture") {
			newLog.data = logData;
		} else {
			if(logType.toLowerCase() === "comment") {
				if(logPid) {
					newLog.data = decodeURIComponent(logData.replace(/\+/g, '%20'));
					newLog.pid = logPid;
				} else {
					handleError(res, "Comment does not have a pid.", "Failed to post comment because no pid provided by server #" + serverId, 404);
					return;
				}
			}
		}
		
		//add the logType
		if(logType) newLog.type = logType;
		
		newLog.createDate = new Date();

		var db = getDbByServerId(serverId);
		if(db){
			function insertLog(index, saveImage) {
				consoleLog("app.POST(/logs/:serverId/:logIndex/:logData)", "IN INSERT NEW LOG AT INDEX " + index);

				if(isNumber(index)) {
					newLog.index = index;
					consoleLog("app.POST(/logs/:serverId/:logIndex/:logData)", "Updating log in db: " + (newLog? newLog.data: "NO NEW LOG"));
					db.collection(LOGS_COLLECTION).update({index: index}, newLog, {upsert: true}, function(err, doc) {
					  if(err) {
					    	//console.warn(err.message);  // returns error if no matching object found
					    	consoleLog("app.POST(/logs/:serverId/:logIndex/:logData)", "Inserting log to db " + JSON.stringify(newLog));
							db.collection(LOGS_COLLECTION).insertOne(newLog, function(err, doc){
								if(err) {
									handleError(res, err.message, "Failed to insert new log into server db " + serverId );
								} else {
									//add the new log to allServersLogs
									allServersLogs.push(newLog);
									res.status(201).json(newLog);
								}
							});
					  } else {
					      consoleLog("app.POST(/logs/:serverId/:logIndex/:logData)", "Updated log in db for server #" + serverId + " at index: " + index);
					      //add the new log to allServersLogs
					      allServersLogs.push(newLog);
					      res.status(201).json(newLog);
					  }
					});
				} else {
					handleError(res, "Failed to retrieve a valid next index for the new log.", "Failed to retrieve a valid next index for the new log posted by server #" + serverId, 503);
				}
			}

			if(!!isLeader) {
				//consoleLog("commitLog",'IS LEADER!!!!!' + request);
				//for the leader

				if(logType.toLowerCase() == "picture") {
					imageFileName = decodeURIComponent(imageFileName.replace(/\+/g, '%20'));
					var formData = {'imageFileName':imageFileName, 'imageFileData':newLog.data, 'imageFileExtension': "png"};
					request.post({url:'http://www.seen.lincolnwdaniel.com/api/v1/savepicture', formData: formData}, function optionalCallback(err, httpResponse, body) {
						if (err) {
							consoleLog("commitLog",'upload failed: ' + JSON.stringify(err), true);
						} else {
							consoleLog("commitLog", 'Upload successful!  Server responded with: ' + body);
						}
					});

					if(imageFileName) {
						newLog.data = imageFileName + ".png";
						logIndex = parseInt(logIndex);
						updateSeq(db, "logIndex", logIndex, function() {
							//insert the log at the logIndex provided by the user
							insertLog(logIndex);
						}, function() {
							handleError(res, "Invalid user input", "The provided log index is not a number. Please provide a valid log index and try again for server #" + serverId, 400);
						});
					} else {
						handleError(res, "Base64 Image Conversion Failed", "Failed to convert the provided base64 data to image for server #" + serverId, 400);
					}
				} else {
					logIndex = parseInt(logIndex);
					updateSeq(db, "logIndex", logIndex, function() {
						//insert the log at the logIndex provided by the user
						insertLog(logIndex);
					}, function() {
						handleError(res, "Invalid user input", "The provided log index is not a number. Please provide a valid log index and try again for server #" + serverId, 400);
					});
				}
			} else {
				//for a follower
				/*run function to update the sequence number for logIndex for later.
				in case this server becomes leader, it'll have the current logIndex*/
				try {
					//convert the string to a integer for incrementing later
					logIndex = parseInt(logIndex);
					updateSeq(db, "logIndex", logIndex, function() {
						//insert the log at the logIndex provided by the user
						insertLog(logIndex);
					}, function() {
						handleError(res, "Invalid user input", "The provided log index is not a number. Please provide a valid log index and try again for server #" + serverId, 400);
					});
				} catch(err) {
					handleError(res, "Invalid user input", "Could not parse int from provided log index. Please try again for server #" + serverId, 400);
				}
				
			}
		} else handleError(res, "Invalid user input", "Failed to find a database for server #" + serverId, 400);
	} else handleError(res, "Invalid user input", "Must provide log's sever id, index, and data", 400);
}

app.post("/logs/:serverId/:logIndex/:logData/:logType", function(req, res){
	var serverId = req.params.serverId;
	var logIndex = req.params.logIndex;
	var logData = req.params.logData;
	var logType = req.params.logType;
	var logPid = req.query.pid;
	var isLeader = req.query.leader;
	var imageFileName = req.query.imageFileName;

	consoleLog("app.post(/logs/:serverId/:logIndex/:logData/:logType)", "COMMIT REQUEST FROM " 
		+ (logIndex == 'create'? 'LEADER SERVER': 'server') + " #" + serverId + ": " + logIndex + " | " + logData + " | " + logType + " | " + logPid + " | " + isLeader + " | " + imageFileName);
	commitLog(res, serverId,logIndex,logData, logType, logPid, isLeader, imageFileName);
});

/**
 *Get the log with the specified logIndex from the server by its id
 */
app.get("/logs/all", function(req,res){
    //the client's current server id
    var logs = [];
    logs.errors = [];
    var completedServers = 0;
    var clientRefreshSecs = 120;

    getAllServerLogs(res, logs, completedServers, clientRefreshSecs, 1);
});

/**
 *Get all logs from the server by its id
 */
app.get("/logs/:serverId", function(req,res){
	//the client's current server id
	var serverId = req.params.serverId;
	consoleLog("logs/:serverId", "Received GET ALL LOGS request from server #" + serverId);

	if(serverId) {
		var db = getDbByServerId(serverId);
		if(db){
			findByAndRun(db, LOGS_COLLECTION, {}, function(docs){
				res.status(200).json({logs: docs});
			}, function(err){
				handleError(res, "No logs found for this server.", "Failed to get logs for server #" + serverId);
			});
		} else handleError(res, "Invalid client input", "Failed to find a database for server #" + serverId, 400);
	} else handleError(res, "Invalid client data in request.", "Failed to get logs for server. No user id or access token provided.");
});

/**
 *Get the logs with type comment from the server by its id
 */
app.get("/logs/:serverId/pids", function(req,res){
	//the client's current server id
	var serverId = req.params.serverId;
	consoleLog("logs/:serverId", "Received request from server #" + serverId);

	if(serverId) {
		var db = getDbByServerId(serverId);
		if(db){
			findByAndRun(db, LOGS_COLLECTION, { type: 'PICTURE' }, function(docs){
				if(docs && docs.length > 0) {
					var pids = [];
					for(var i = 0; i < docs.length; i++){
						if(docs[i])	pids.push(docs[i].index);
					}
					res.status(200).json({'pids': pids});
				} else {
					res.status(200).json({'pids': [], 'result':'none'});
				}
			}, function(err){
				handleError(res, "No picture logs found for this server.", "Failed to get logs for server #" + serverId);
			});
		} else handleError(res, "Invalid client input", "Failed to find a database for server #" + serverId, 400);
	} else handleError(res, "Invalid client data in request.", "Failed to get logs for server. No user id or access token provided.");
});

/**
 *Get the log with the specified logIndex from the server by its id
 */
app.get("/logs/:serverId/comments", function(req,res){
	//the client's current server id
	var serverId = req.params.serverId;
	consoleLog("logs/:serverId", "Received request from server #" + serverId);

	if(serverId) {
		var db = getDbByServerId(serverId);
		if(db){
			findByAndRun(db, LOGS_COLLECTION, { type: 'comment' }, function(docs){
				res.status(200).json({logs: docs});
			}, function(err){
				handleError(res, "No comment logs found for this server.", "Failed to get logs for server #" + serverId);
			});
		} else handleError(res, "Invalid client input", "Failed to find a database for server #" + serverId, 400);
	} else handleError(res, "Invalid client data in request.", "Failed to get logs for server. No user id or access token provided.");
});

/**
 *Get the log with the specified logIndex from the server by its id
 */
app.get("/logs/:serverId/pictures", function(req,res){
	//the client's current server id
	var serverId = req.params.serverId;
	consoleLog("logs/:serverId", "Received request from server #" + serverId);

	if(serverId) {
		var db = getDbByServerId(serverId);
		if(db){
			findByAndRun(db, LOGS_COLLECTION, { type: 'picture' }, function(docs){
				res.status(200).json({logs: docs});
			}, function(err){
				handleError(res, "No picture logs found for this server.", "Failed to get logs for server #" + serverId);
			});
		} else handleError(res, "Invalid client input", "Failed to find a database for server #" + serverId, 400);
	} else handleError(res, "Invalid client data in request.", "Failed to get logs for server. No user id or access token provided.");
});

//returns the last index sequence for the server by its id
app.get("/logs/:serverId/lastIndex", function(req,res){
    //the client's current server id
    var serverId = req.params.serverId;
    consoleLog("/logs/:serverId/lastIndex", "Received GET LATEST INDEX request from server #" + serverId);

    if(serverId) {
        var db = getDbByServerId(serverId);

        if(db){
        	function insertNewSeqAndReturn(cause) {
        		//insert the first logIndex to the database as 0.
                db.collection(COUNTERS_COLLECTION).insert(
                    {
                        _id: "logIndex",
                        seq: 0
                    }
                );

                consoleLog("insertNewAndReturn", "CREATED logIndex sequence number for server db #" + serverId + " because " + cause);
                res.status(200).json({_id: "logIndex", seq: 0, 'cause': cause});
        	}

            findOneByAndRun(db, COUNTERS_COLLECTION,
                {},
                function(doc) {
                	if(doc) {
	                    consoleLog("dbConxCallback", "logIndex sequence number for server db #" + serverId + ": seq = " + doc.seq);
	                    res.status(200).json(doc);
					} else {
						insertNewSeqAndReturn("logIndex sequence not found in database for server #" + serverId);
					}
                },
                //if an error arises, its likely cause the doc was not found.
                function() {
                    insertNewSeqAndReturn("Error occurred trying to find logIndex sequence for server #" + serverId);
                },
                false
            );
        } else handleError(res, "Invalid client input", "Failed to find a database for server #" + serverId, 400);
    } else handleError(res, "Invalid client data in request.", "Failed to get logs for server. No user id or access token provided.");
});

/**
 *Get all logs associated with this server by its id.
 */
app.get("/logs/:serverId/:logIndex", function(req,res){
	//the client's current server id
	var serverId = req.params.serverId;
	var logIndex = req.params.logIndex;

	if(serverId && logIndex) {
		var db = getDbByServerId(serverId);
		if(db){
            findByAndRun(db, LOGS_COLLECTION, {}, function(docs){
                //find succeeded
                //update the request
                //consoleLog("/logs/:serverId/:logIndex", "DOCS found for server #" + serverId + " at index " + logIndex + ": " + (docs? docs.length: 0));

                var docByIndex;
                if(docs){
                    for(var i = 0; i < docs.length; i++) {
                        var currentDoc = docs[i];
                        if(currentDoc.index == logIndex) {
                            docByIndex = currentDoc;
                            docByIndex.familySize = docs.length;
                            /*consoleLog("/logs/:serverId/:logIndex",
                                "FOUND Log for server #" + serverId + " at index " + logIndex + ": " + JSON.stringify(docByIndex));*/
                            break;
                        }
                    }
                } else {
                	consoleLog("/logs/:serverId/:logIndex", "NO DOCS found for server #" + serverId + " at index " + logIndex);
                }
                res.status(200).json(docByIndex);
            }, function(err){
                //failed to find the corresponding log by id and contributorId.
                //insert the new request
                handleError(res, "Invalid client data in request.",
                    "Failed to get log for server #" + serverId + " at index " + logIndex + " " + JSON.stringify(err));
            });
		} else handleError(res, "Invalid client input", "Failed to find a database for server #" + serverId, 400);
	} else handleError(res, "Invalid client data in request.", "Failed to get logs for server: no serverId or logIndex provided.");
});

//delete all logs by serverId
app.delete("/logs/:serverId", function(req,res){
	var serverId = req.params.serverId;
	consoleLog("/logs/:serverId", "Received DELETE ALL LOGS request from server #" + serverId);

	if(serverId) {
		var db = getDbByServerId(serverId);

		if(db){
			//delete all logs from this server's database
            dbClearCollection(db, LOGS_COLLECTION);
            dbClearCollection(db, COUNTERS_COLLECTION);
            consoleLog("/logs/:serverId", "Succeeded deleting logs and counters for server #" + serverId);
            resetAllServerLogs();
            res.status(204).end();
		} else {
			handleError(res, "Invalid client input", "Failed to delete logs for server #" + serverId, 400);
		}
	} else {
		handleError(res, "Sever Id not provided by client.", "Failed to delete logs for server #" + serverId);
	}
});

//delete all logs with index before the provided highestIndex 
app.delete("/logs/:serverId/:highestIndex", function(req,res){
	var serverId = req.params.serverId;
	var highestIndex = req.params.highestIndex;
	consoleLog("/logs/:serverId", "Received DELETE LOGS BELOW highestIndex request from server #" + serverId);

	if(serverId && highestIndex) {
		highestIndex = highestIndex.trim();
		var db = getDbByServerId(serverId);

		if(db){
			try{
				highestIndex = parseInt(highestIndex);
				//delete all logs from this server's database where index < highestIndex
	            dbRemoveWhere(db, LOGS_COLLECTION, { index: { $gt: highestIndex } }, function(removed){
	            	updateSeq(db, "logIndex", highestIndex, function() {
        			    consoleLog("/logs/:serverId", "Succeeded deleting logs with index less than " + highestIndex + " for server #" + serverId);

    			        resetAllServerLogs();
						res.status(204).end();
					}, function(err) {
						handleError(res, "Invalid user input", "The provided log index is not a number. Please provide a valid log index and try again for server #" + serverId + ": " (err? err.message: "unknown error.") , 400);
					});
	            }, function(err) {
	            	handleError(res, "Invalid user input", "The provided log index is not a number. Please provide a valid log index and try again for server #" + serverId+ ": " (err? err.message: "unknown error.") , 400);
	            });
            } catch(err) {
            	handleError(res, "Invalid client input", "Failed to delete logs with index less than " + highestIndex + " for server #" + serverId + ": " (err? err.message: "unknown error."), 400);
            }
		} else {
			handleError(res, "Invalid client input", "Failed to delete logs with index less than " + highestIndex + " for server #" + serverId, 400);
		}
	} else {
		handleError(res, "Sever Id and/or highestIndex not provided by client.", "Failed to delete logs with index less than " + highestIndex + "  for server #" + serverId);
	}
});

/*****************************END LOGS REQUESTS*******************/
/*****************************END LOGS REQUESTS*******************/

/***************************END REST API ENDPOINTS**************************************/
/***************************END REST API ENDPOINTS**************************************/


/***************************START IMAGE MANIPULATION FUNCTIONS**************************************/
/***************************START IMAGE MANIPULATION FUNCTIONS**************************************/

/*function saveBase64PNGImagetoDisk(base64, ca){
	var base64Data = base64.replace(/^data:image\/png;base64,/, "");
	
	var uniqueString = (new Date() + "").replace(/\W+/g, "");

	var basePath = __dirname + "/img/uploads/";
	var imageName = "img_" + getRandomIntEx(100,99999) + "_" + uniqueString + ".png";

	consoleLog("saveBase64PNGImagetoDisk", "imageName: " + imageName)
	fileSystem.writeFileSync(imageName, base64Data, 'base64');

	consoleLog("saveBase64PNGImagetoDisk", 'It\'s saved!: ' + imageName);
	return imageName;
}

saveBase64PNGImagetoDisk(getTestBase64());*/


function getTestBase64(){
	return 'iVBORw0KGgoAAAANSUhEUgAAASkAAAEoCAYAAAAExQcnAAAACXBIWXMAAAsTAAALEwEAmpwYAAAABGdBTUEAALGOfPtRkwAAACBjSFJNAAB6JQAAgIMAAPn/AACA6QAAdTAAAOpgAAA6mAAAF2+SX8VGAAAxh0lEQVR42uydy28lSXbeT16VbMkwUFzaoIEi4JVGj6Ieo262xl0caaSxBAFNw/C6SEE2oFVzjEIVZAHumr9AFPwHkP0XqHovYKo3LgvQ2GxYWpu9KGmmu6t4uRi9PMzQ4mZeZkaeE3EiMiIf935nwGk+7ou3Mn78vi9ORBTGGEKh6vrrv/nBo+rTveqDiGjPGLNn3XTfGLNTf1FfRt//g/9O1//7r7iHvqo+mvWS+fzq5PWrz/EvgarrHt6C7aof/PCLBxV89oloxxhzSEQ71ddiFUVBd0Ayne8Vxd33hWpCr65D7obnuwdEREsiumzA7ZKIlievX32Kf0VACrUh9cMvvnxUwWevUj6HLvjUX9uwsb+278NBK0HtcBCrAFaD62UFr0uoL0AKNfH64suvHlQQOqzAtO8DkgQiH2yc0CoG+XVrVXbYgFetvF7W8Dp5/eoGVwYghRqpvvzqzUMiOmyAaUeCiyZ35O6rVUgTyTVr5dUEVxNaLwGteVaB4Hw2ULpfDcCj6r97oY8h/VuHXAPcbZvf+/P/8kd0/f2/murbWAPrxcnrV5/hqgKkUD3rqzdvHlRQOjKGDkMin9B/Vh98tPf58//8R/T2+385h7d3SUQvKmB9gqsNkEKFg+mYPDNuKcr3z9+8PlzXSv2zGUHKBlatsD7GVQhIoTpgeluByVRgypk++/+9XZeED1r/6/f/2xwhBYU14UJwPi6cHtd2rvqbIf81iZje5/8AFV6AcU9VP1SfcH4mtVOp2ONqxvCCiC6QYUFJbU29eXv9wBhzWg2EnVgApbN7vn9/o1Ja9eO8+v0/pLd/8Zeb+E93SURnlcLCLCGU1EbC6XEFpkMJSoVP6Kxv5+h3CrRzfmVUdJ7Bvosxd49TULGp/4T7lapanu8eXBDRGRpIoaQ2AUz3iahWTXsuGI0xuDtAM3JixV8n3e/9z9/7Q3rzF/93W/6JXxLRcyzVgZKapaUjoue0ypp22g3ZGqmUCVh2p3iXlFRY8OKyKF5lbeUfu0Mienm+e3BVwQozgxlqgbcgXb29vn7w9vr6vCjoqijouChoZ1EU1PxfB0bch4Nd2o/gB7DgVf9vURSdmxVF0fq4A1axrf/0e0R0cb578P/Odw8eYyQAUpOr6+vlg7fX1+dEdFVQccxCyQGGXuDpATTvHXzQoi60trwAK0BqenC6vl624CQOej8LGrcpsn0ECTkftBrAQgFWgNRE4USrULw7qN3jXA2S1BUDL+fvZyksArAAK0BqVDjdv75efkSrnpljbuBqoeSFSYb/hcLLCS0RWCgHrP7P+e7BI7wdgFQuQD2ulNNzKoodCUyhUAoGSo/wKvS5NNDqfgOYctQ+rWYD//R89+AB3g5AKhWcHl1fL79HRXGxhpMCTFpIBMFHawUDH0sLLhewUEF1RERX57sHH53vHtzH2wFIxcFpeXP/enlzTkXxkoriUBqULjAFASmCMaEfKpj5XrvwewNWUfWciC7Pdw8+wFsBSIUCqrZ2x5xq0oLJHeqkaTUIKRXAFNDSKCxUUF714nz34HuwgICUBk4Prpc336PVGq0dSTV5waSEkhcqA4XmztfG/CDkcVHqOqxU1Yd4KwApCVAf0mrW7lADJyeYAqAUA5aY9oXQ59G2IQBYSWuHiM4qVfUQbwcgZauns6K4W2cn9hAFgEkDCy18tJYqqqkzEFokBHQAFVQVIJUne7osirv9w4NUkwJMEgCGbuLUwEwLLWcLAjiVss6QVW0ppKqZuz8loouiWG08Vw9cUTVZcNKCSYKCw5fl/1CCy/X7aJUjKpmq2tqO9a3bqmV5c/OoKOiCmvs7MXBqjUISvxStTqFLxlWKp2919oLiHtL4n9sY0/o97f2oIKSyZlUX57sHh0R0um07g26Vklre3HxEq43K9jhrp7F0LsXkVUqCosm9jk/1+Aq11emNQmg+dB3TqmP9ISC1eXC6v7y5+R6tmufE3ImTSy442YNXA6VYEOVoO3DaUA+0ZMADWJlrvwLVY0BqcwD1kKrWAm/uxGRO0m1FyHiUUiyEohRUxGOqoEVhvxsqm/07B6TmD6jHFaD2tNZOC6c+YOoDoZSb42lehxNYGfIzVJj9q3ZWuA9IzRNQ57TqHJetXSo4BYIpN4D6PE4QsBQzhqhB7N/VJudUiw2EU50/HXvVUwI4xTZIDrlmTwuyJMBCjWX/NrZNYbFhgHpAq9m7Q6166gsnaWD7wNBLBiXdCkH3+jTAQo1eF+e7Bx8BUtMFVB2Q74eqp75wkpe5xG+VMqiEKvxKT/f7olFqAvV80wL1xYYA6oNKQe0U3Foyj3pqDbIIOKnVUiIgpZ4F1Mg8n8JCTao2KlBfbACgHhPRi6IoZEBR51O3euoBpziPpwOQaq/yFP1Tyg35+OdFTaT2adVPdR+QGh9QF878SbB3WeGkzYBSKqGeSixGZWHN3mxANeuZv8WMAfXHNqCk/ElSTx1rJ9i+YDgp4ZAqTkoRbQUDC7ACqAApJ6DOieg0JH8SsyeHelLByZflBC9TyX+CcajSCoEVapK1M2dQLWYKqGNX/hRk7/rCyTPQQ0EyiN0LfF4VrEAogAqQ0gOKy6dc6onNsyLgFL0lrwos/Y5UDwFXtCXEuXsA1TZDKhRQYv4kZE/dnQ2EzClQaQTZrMRbtsRvQawHFgqgAqQiARVq75wskhoeFXAKgciQpT7AQblnOwqg2lpIVbN4UYCyRpPX3mmtXZ+tdKOglGkZTOjrAqwAKkCqC6jH5JrF0wBKyJ84e+ezdj449QZTjtNCo9bweY6LR1a+SaB6MfWGz8XEAXXRG1BC/hSinmLgpDt0YULbIPQEFmq2tUcT70yfJKSWNzePUgHKlT9p1VMMnKJDnrEqAFjS3VGzrf0pg2pykKp2M3iRClCu/ClWPQXDKRJMQx6zHvJ6xW1qAKq5g+oMkPID6j5VuxmkBJQzf+qpnuRDGPovLE4qlGIfPwJWqNnW8RS3eVlMEVDdmbl+gBL/2gcAKhhOgdAYxeElWGQMWG0kqCa1w+eUlNQFMRvWcaCIARQbkHvsHbslSQ84pYBSjsXFwa/PCSuM8g2oi/Pdg0eAVFtFfURER779oPoAyiWNQtRTHzilANEQ91e/ZkztbXK9ON89eABI0brV4HnQerxYQAkBeS/1lEA1DdmJ0GdHBOeDojatdmgiPVSjQqqayTtjoeHZbiUKUMwATK2eYnY/GLNigAVVtTW1TxOY8RsNUlVQfkF9gnIHdLIAKhGcplpJtm5BbVodn+8efLitSuqCHEE5BxRNL5QPUFJA7rV3Sjj2USp6mKTdLSEWqADV1tTZmGv8RoHU8ubmQyI60ti82FYDCVC+OCUke+q7C0IOEKXf7gULi1FENGI+tRgBUOscSmPzmFHhBJRrMAUDKtMWLRq45LFz/Z7Dt78UaqNrr3I/mw2p6+U6h6KofqieQXkwoCKsXSw0xqiY5/epKuzMudF1NEY+NbSSek6rGQPR5omA8gDDl0PlBFRYD1MxyQ7t0NeFybytrcHzqcEgdb28+YCITkNsXqqgvC+gYveR4iCQiChZT3EIhRVq62pQ2zcIpGqb5z7i3KFYHDZvCED1GZzRcIppG0+8Xkb72qGqtq72z3cP/njTlNRFUax2NvCBQbJ5fWfyhgZUFJxyd3jGbhkTACvU1tTpUOv7skOqsnlHLtBoZvNC7pcLUCGHK0wGTAmfF7sdoGzxMURbQlZIeW2eT0VF5lC5AKUZxJMGU6LXA1ChqtqjKmees5I6IxJsnhYiPvul3X0zI6DUCmMO4Y12PyyoKtSqnuee7csGqevlzSMiOg5VUbbNqwdCbMPmEIDaCDj1gBUKtm+uSurCBwif0gmxea4cKgeggo6omnMpj8BCbXXt52zyzAKp6+XNR0S052o50KioEJunVj+JAKUa3Lm44fjICivYP5Tb9mUJ0ZND6np584BcYVoqFRVr83IDKqF6igFRVnihIQol1w5l2nsqvZIy5oyIdgpHppRSRfWxeVkAlRBMudRXblWF2to6ztE7lRRS19fLR1QUR6HXeB8V1cfmTQVQg9i11M8HUKH4Sq6mFjlfYLCS6amixOeO3JlTBageFmgKewb0eg0AFapb+6mPxEoGqevr5WOqdjgoArrEg1SUMiyPyaGiATVTOCV7TcipUN1KGqIngdT19fI+ET1vqZwcKkoJvqDnJffR6SkBNYfdlnrBCoVa1R4l7ERPpaROqxc2iopSgyVgbKUE1By3ggOoUH2ZkEpN9YZUpaJOQy7eqaioqDEVAai5VhRcwSnUqnZSqakUSuqUiHacVi9SAfVSUX1m24pi6wEF7qASqanepyD3gpStoqKsXi4VRRSlooqEjZibVAAVKlJNPR8VUobMafVC4q1eonjDpaKSnGSiVXMbPKABKlREHfdVU9GQent9faeiAq2eJjDn4BCrorS86WvztmEQA1SoGNs3lpI6LajYibF60hXP7lueWEXNFVCuQz9zn2YMUKESqKnomb4oSLVUVAarl0QuzV2xJDl9OB+wACpUQO30UVOxSuqI6iwqkdWLDcw3TUVlg0oGYAFUqBDnFaumoiBljDuxj7F6kxNPAwNqyP2YUj4XQIUKUFNHg0DqzdvrxwXRXmiI3cfqpQjMc7QcpATUWJYSoEINWM+HUlLHqqtygP2xs7UdaF77zNTTlF8Damtq73z34IOskHrz9vohER2yaicESolm9eaqYMZ+7ix/MDAAUbo6za2kTv0Xa4Jepp5Wr9cavQFU1FSVC0CFGqAOQ5s71ZB68/b6PtUnESfIo3JavSmDYurWCqBCTU1NhSipIyLaKXRXesBFXWQedNNRUXPJfpBRoTLXcRZIGWNOpVFaJAjJU40LDfTGGIRzG/gAFSpj7YRsMayC1Fdv3j6kamtgF1X69Edxd4xp4Mw6cLdswANUqIx1lFpJHccP7GIuIxKXDQo1IKS0AboaUrHHTI35Fzrl02ybioKaQk1FTXkh9dWbtx9QY88orzIaMTSPzqMyDcRNGeAAFSpTqRyaRkkd5VYTQTtsjpRHoVCo5LV/vnvwMCmk+ncx6v1Zqg3uxrJ6m6Y+oKZQY6mphdvqvWlZPRYmCbOqtIMK//oo1AzqqK+SOtI+0xxm8YbKo6A6UCh17fksXzJIjQ2uXM8F3AC+qHHV1CLY6uFCR6FQU4AUNbZkybNHds/HBOxQqE2pfVdjpwgpY9x0G4MRc1Bhm64UoYRRmeowCFJffvXmQVHQ3hTUDcYECrXdlm8RcocYizbU7ge+x4QCQKE2SEm57jCIpRhqTs0HUFw4KNRQtXO+e/BoNpBCoVBQUyKkvvzqzUPK0HqAQqFQSSBFPRs4c1kvFAoFSBERkTFmf5SXZwz+iVCoLS8ul1poaYZCoVBjqKkWpL748ivkUSgUarqQymH1TISNMzSQ9fO8NhhQFGrw2vfZvcOh4ZEjiuIe0yDzQqHmUDv2Or6FRLGoMW3mATEUCjUfy7fwSa0pwWMOamjTFRsUKWpoy7eG1A+/+PLRkBdmb+uIwYJCbRekiFa7HuT+S4m/xCgUqhekJqWWJvBccdHcZoIYf2BQA1UrPG9C6rDPxWhopnkRBh4KNcXa60DKGLOn1hKNgc0N/CmMe7AHhZp1HcbZvb4D33f/JvzITAY4sHyweqjhLV8LUj/44RePcg1WzQUecv23HivVwMEABKBQU6t9W0nt6FWFSTbgU+dYmscbcsBhcKNQ0bVnQ2rfx5uU2dNQgzfl0+RSkVBRKJQCUsaYnRQXJqdkzFyW6WIwolCTqvr49ZaSMmHhUNyPE4TnfXOpeAhvlxqBikKNXDtNSHkuUOMcqZqLOWV4HqLmpjLO5jbgASjUVCxfbfcOk6qJEcPz3JbPbMHAB6BQk4OU68Jkm7QDe5jYrCrKpo1v+TYdAH1fH/CGSl2Lv/6bHzxIeQGrAGY8EBJyqUEsX2Y1NWVQAVCoidVhraT2uAtVdcF6lsdoB8FYlq/PoNw0UAFQqMkqKf2FG7hMxeRprNRavl7gG6yPy4wOqym8BhTKB6m9GGCkyKXUKi3B32ljpqemxlZVqZ4XiEMNZvc04XmuXKq+z2T+qCtfSEpQmRkqOAAKNSG7p1A8ERbPqGEQ3tipDdCNMd7fbaiBWgMkNbByPC4AhRoEUvyaPAk8/XIprW3jZvmmXjleaV+w5AIeAIUasu7VF3NRFOv/6i9UQwUVa5407+r6WetKF+6jAVn9mK3XbT2Z/ZjSaxF/d/HFe3+d5MDaZCCjUFyd7x48XJC1A0JULpXT8iUO0HPavm0YwAAUauDaWZCwl1SzXypkHV9yyxejNFK2IwBUABRq1Fr0nYJ3zeQ5f1Z/w3Efn5oK2rShb4i+5QMagEKNBim/ckpg+SIbO1OqqaFt3yYNbAAKNQlI+QZ/L8vnUTUqNaVUaCmsZmpQzXWQR712EA2V3u65wnKjvJB7Wj6NmnK8lpBm0yT7TUWdS7gF6gnLa1AZ6t6fvfMf8S6gktW//U+/Tfv/9X+o2dX9mRG/Xt3W9Qex8Rn7M2vxvBEet/F/6z9qpv39tcNY/6ztLgyZzmL95vOuf27u/njWX5vqRZn1fZo/a3zeuM3d7ar7rH9Wrn4/Y6i0Ip31B7W/rm9rpI9y9ZilKVvfK1ffvLtv9T1jDJVluX7csizX31v/t3FbW2jcw7BCpax/+W/+Nf2rg1/yKlvfPmWsXTc6xU6mu8TKiIAy1s/vHqPtAkznZ6b1GHf3bw40Luu9G/B3r64sy8b925/Xt20Cq/kYq/+WreeuP0pTroHW+rwGRAM09ffIEN2Wt53v3wFl9fltedv6vChXj7co78BDpiQqDVH9fLe368e7rT63P6IyKRQqzv2l26HV9VgcoNzwi4djCDh1r78JL1spyoBvAtIFQhGQZMSVJarPSehfZISw7zX5/n0BKdTggDKhbSdGzhEluBnFXvwhj+uesDbq51GvVTVdILmgKK9nJe/n0u25120Dzra1LetIuvfB954AUqhRARV6o5DZ3OQqSrKOgUBqWj174qp7H9OxlN15V/9mkob0SsmlsnwQ41SUSzVp3q8FES0xrFDDwKtfDqW1iNlUlNCA7IInl0+1R3zX6jXzJ/fv1xz8xgucDnwo0u6tw3nr8yaYiFdSGuvHQeoSwwc1CUB5weKHm/s2aVSUER7UDaS498y2cZwNlDIqEsRXbB7FwUcCXQtgwmMp37Ml7B5qOoDKZPP6qCgNwMLO1JWsHtcwncbqdb5vqZ6WPSPjtWExeZSda2nzqGdPn3wGSKEmCSh1u4HW5kWqKBtgUmDOWZYwq8dnVLKy8lu9JjzW3zd+kEuBeZ88ygcozO6hZguo0AzLZ/OGUFGawNz3Xtm3tZ9TY/W4z9dqh+LaAu4aPq3PyWTJo4hWzZxXGE6o3HCKBZTW5hmjt3lTUFHthk7ZzqW0eq27GPesneG6011ZlLE+V/RHaTO8BSCFmgugpKbNWJsXNKPXU0Vp3ztjSLCAgmIKsHq+mT1N64EIGdcsYmR/FBG9hN1DDQOu1IDS2jWNzdPO6DmaN0VLxNo344RMJwfqKCsJaj2tngYshldK0nvdtz8Kdg81DpxSACpyNk9sW1D2RXEqymdZjHr3Dl9vlDTb53gf7M9dVs+QCBZn6wFn6xjrGJtHEREtTl6/+hzDCTVHQKW2edwaPW1flE5FcR3mJN7WdV9uIbNTFXl+Z+4+7GJsdieGbm4lLqkJy6Ng91CbAaiUNq/zuCY+i9J1mBtWRYUE5pIqSmr1uIyLmD8IjtaDUAW1VlJNYqFQKRDFwmkAQCW3efWYN2YgFSUH5rZy4gJzzexbtNXz5V2ORcWuHikPrK6gpFADMMuvMJICKmBnWKcKEsLy1Cqq/TMuMDeMcnIH5px6av5Po6SCrF5TpRnfHlqGVVoaSF1iNKE2CVA+m2dnJ0GzfQlVlK2WOBXVVk7K3iiHWxSBRO5ZPdbqUddehux84Kkl0d3OnEuMKNSQcBoCUFqbx/18GiqKU04kqhE7d3IBqdUpTu4GTm4mr9mO4Ns/KqaBk2i1bg9KCjUQs8YFlO/+Ume5tuVA/l6cimq/Pn/bAaecOvuXO2b0tA2cMVavR3h+VX8CJYUaFFChe0p5cyQtoHyzeaLNi7IpvVSUtu2As16+wJzdxoUUS1dM1/aJYDRGtTWLp9aQWhARnbx+9SmGEyo1nFIDyrUmTQMo32yexuaFqShuwIarqA6NyRGYm24DZqcRU6GkOPi5GjhTW72mu1tw5EKhUsIpNaCCZvJYeBlnDuWzeW4QGwE6d9Kjraj8Kqp9KoxORYWoJSmv8mZVRmf1XLbPUUtACjUQtHjghGRQqWbypBzKzl98Nk8blrv7mjKoKIc6igrMhW1ZRDWlmNULsMwvOUhdYkihUgPKq548gIrJoXwKjLV5DKDibZ78PrS7y+NVlE85cctUYgJz7qBT15IbDloRVq8lmu4BUqgpwMkFKO9q+x5BeTeHirN5kopqZlMuhdnsKteoKDF/cqioIAtoSDUraD9nggZOIqLls6dPPofdQw0HrZEAFRKUa5a+uGxeG0hy24Wkorp9UT1UlNB2ICmpzudMSN6Eor2wuANP6rdWzxZMa0hhhg+VA04ae6fqg+oBKPHsPAFQrqZNnc1rtxx0H994VBTfXa5WUYZYcJBRbBcs9EZJX2sCc84uR0EKlg81iHrqO4MXCSjt4mFt06bP5t19bf/q3E4HTTjx3eUtUCVUUR24KALz5vNqZvACrR4ghcoNpzh7p5nBSwUoXz+UZjD5bF57zV03HLfv71ujJykiSUWRIW8+5Ws7kAJzCTgJeqNUkHqJYYZKSy2jtncuQPEw6wcoTT9UGpvH/+7d2b10Kqozq2eoa9U8KsrV3iDlWj3C8rqW9Zq9uu5BSaGywUn+UoYTkarFIB2gFF3sDtXA2zxilrXoWw7GVlFroHGgc0BO9TyBKqqjpE5ev/qMsI4PlVA5BQFKGZCnBlRIDtUFEWfzup3l/rC8aw87H9ye5QlUVEclCefqxXSYR1i9l05IwfKhcvKKy56iAvLMgOLVUpzN446j4sNyd18Vp5BUM3qkUFWlYW21q+0gU2CuhhQsHyq1mApST96APDOgXNvctgHlm81z27zmjF97Wxbi8yJrWxSpu1yjolxA0WZVkoqKtHlERPTs6ZNOK9Q9KClUVmAps6fY/CkXoEJzKN9snsvmucJyztpx2RCrohzZ1Pp1l46mTEtFERGVpvSCqUdozrKno6Sqpk7kUqjecOqrnqYCKG0O5ZrN69o8LiwXYCLsfikdJeXMmoiCvubCee1xVRH7b+kgBTWF6gcncp4Y4lJPoQH5kIDS5lBam2d3ltsnwkj7NHUaKIU1e6oZPqWKkk6TKcsyZesBIIUaI5sy/dWTJ3+KBRSvxjSA4hYPd3Mon83z9USxUCI+HyIpwzJpVFQTRiGPEZhHLbk8ygWpFxhiqBxwilFP3v2gIgClbTVwB+XtHIprN/DN5rnW5znDcureZv18dbhNDohEqqhMbQdOYcRCqjp6/QrDDRVBKCecYtWTmD8lApSsrHhAhbQbuGbzjNQg6QvLOfXUeC+aAbcIwB4qqixLFl62BQyoF0GQgppC9Q6mHHDyqafg/CkBoNzgcgNKl0PpZvOkznIJNJ33SHFiS6e7fHwVFa6kkEuhUts+frZPUEQB+RMZUofk4aBqZ04+QOlyKP9sXqtrnByHK2jaEIgP48XZwx4qqkdgftnc5E4NqZPXrz4htCKgMsFJkz1p7J3p5En6WTw9oPhucAlQmnYD52xes2GSs3mG+COkmMZN9mgq4sP41nOWRgWi5kcTXoHldG2LPndGoeRISgEnT/bE2Tt3/tQPUJ3fgQUUqQDVzqHa4VLIbB4bqnNqU9O4KewX1cqRPJDLoKIAKdTwgVQInFzqiW8vcOdPfQBlB+X2rpq2uuKe05VDcdsB+2bz1nAwJWvzpLBcmrXjTjeWMq368TT9UD1U1JW9NUsQpGD5UH1VlQZOTvUUaO98gJLCXf9MHrFqyBeUh+RQ3tk8KczWHG9etRzU4GED88bvXZqy010+horSKCmoKVR2OHnVk7BRnS8g5wAlg8sFKO41GuKWx7gAZedQTQumXfrC9UTFhOWtr0shQLeUUgYVRUR0AUihBjZ7CeBkq6eA/CkUULZS0rYadGfyNEG5st3As/TFZ/NcYbmq30rYL4p7n3v0RamsngpSsHyoYEqlgJOlnkLzp6EAZZ/wognK1e0GPWyeFJbX92vCZZ13mbiPHirqTHOjhfLBLjD6UGHRuftATXFZS2L15AcUN+DCAMUvHCahbcHTbkD8jpwxNq8sy/Xjr6FUKa+mgmsF6tSwf+RvOeihotQuDZBC5TJ8IpzENgRRHcnqSTOD14UX3wfVD1BS7mTETezYHMp37l2gzeOgxGVTa+CU7gBeyqZiAOVq4AyGVLX3+SUGIEofnhsmUJZyJ9fMnV89hSgoe3O69IAyQutBd39yCVi1/RJtXIzNKz1hObPez4aSa3Yvl4oKUVJq/4iCjmIzJ0fuZOwg2aGeOIWkPamEO9uuC5o0gDKu/ZwMif1Q3Ba9nfsG2Dzx0E+S4cdByTW7F1HLZ0+ffKy98b1A8i2JaAdDEeVWUfI3jNDXxNlFF5xC7J0uIKeO+kkFKDYoF/qhnJvZ1R3iATZP7Cw33fV52paDBCoqKD5SK6mT169uCO0IKG0kZXk8KRSXrF2oepoLoDiFw4JMAa5Qm1evyWPX5ynCcltV1Uoros6yQAqWD6WmlOGaEcPhFDN7JwXk7hYDDjZ5AMUF5a7dDdhz8ASQ1PCwZ/NcHeJrtaUMy3s2bhIRvdQG5lGQqgL0lxiIKDem6iC2mzn1gZM+HDfs6S2ugJzf8SAjoOygnFtbZ+ROcC6Lqt9oezZP0xNlg0iTSw2homKUVLCfRG1jcO6ajUsPJ7+9K5nWA3nh79CAam73K+1u4D1KSpi9Y2fzSiP2RGUMy4lWHeafZIfUyetXHxO2FkZ5MqnuxczDSROM+9RTiL1zzeARDQso38nAtSqVAOXsd7KDc+vxS1OKPVGZwnIioucxd1pEPhmyKZRs9Tqqya+c+qgnvb0jR4uBnEvlApQ3KFdsNse2G3hApmkzWOdbtMq3EoTlS4qceIuF1AVhPR/KbfoaUOkHJ5166to7OSB3zeBRB1pjAEq7uwHXbtAKzjmbZ83m1RDywaqHgiIiOnv29MnNYJCq2hGgplAypowucwqBk2Z7FdnKccDi7V3bKo4PKPH9KPl2A9cyGNdsXuKDPm0VFc2LRR8yQk2hOBHFbUCXGk7d7KlU2bv2B5c/dbcLDgYUWScJcxvdeQAVm0N1gnPimzOl2TxX+0GPehGronpBCmoKJaso47zAtbs6+q2dtPWLz965A3LDTvkHAEpQUs01ea5WAx+gmv1QzlYC0967vA7LXbN5zezJXqvXo573ufOi5/UINYVig3MJTFo4uaydL3vi1BNn79zr91yZlGOTOBegrNm8rgLVAarZD8UuexFyKFW4ntbmERFdhDZvJoUU1BSKzcwF4MTCiWsr8LUR6NWTBCMSZv08GZQSUKFLXjpBuQWk9WsrDZ9DlV3YaWbzegKqt4pKoaSgplCi3fNtJ6KDEzF5UXdPKHc47sufuCPPSyZE94fkUYAyfvXJBuX2Fitle/sbLofiHtc1m9fX5vVVUUkgBTWFsu2eOMh8Z8Ip4NQEkaSepHDcnT9xG9XZAFTM4vUAlHYmj+0ELw1rF+0cqqmSuHA8oc1bpuLCItG1CTWFamcritBcB6fS2YApZ09aeye3HJSlPKsmZU8hgArKiDSzdPUxVKWi/YEJxxM1ba6Z0GdGLzmkKjV1ihGKanec+yxdCJx4a+eDk87euQPy1mtW9EFpAaVpM7Bn8lrr/rigPCCHyhSUE62WzSVzV6mUFNb0oQKyKXIE4qXYUsBbOwpST/zXpW4pigZQZVpArTvIm1v7Np+zdG9W59rUzm43SNRZXmdRN5ODVFXHGJqwe1rVFAonXj2VwepJ7ign555Lqlm9xICyg/GOUqMukKR+KE0OlcDmXYZsDTw4pE5ev/qUsHsnOMWASYaTiYST/fjGoZ6IzZq6M3qO/ImsHiffUpdUgGpaOgZY9nNxNk+bQyVQUJQj9llkuEaRTW19JqUDUyic3MtayKGeNN/z5E+apsjcgCp5RWUvgdH0Q2XKoi6ePX3y6eQhdfL61eeUoIELNV+7J4OpdDZixsCJs31c9sSrpy6YmuvgpB4oadmJCwSqtXjSSS4CoJozeev9oaxg3bXjZuIcaplr3C8yXapnCNG3XE85wUSOqX9yqB5X7kQdEHUfX2fvXPlTs8Ugtv9J/PD1QlmtBlwGpQnKM+RQdVj++WwgVbUkIETfUrtnZxzyMpXuz7sDSBeKcyByZU/d7ExYg0eMOhEUFNdcmQJQ2lYDbk8oLihP3A9Vh+V/kuuayqWkEKJvud1ztRnYO3XK8OnCyb2TJnmzJ29ALvU6aWxZ7ELeAEC5Wg2IiLV4mYNyyi1I7mW+ZI8r27eD0bs9jGqfY2d3nDctYdsetn9O1jbE3Na/RPwSlu7tvOE4N3vnWzxM/v2gWMXGhOQxgHK1GmibN1NEO8+ePvks5zW1yPngsH3bmkeVzPIXKW8qHefy+XIn2xbq2gq4cJy1d6UjIFcASjuL1xdQvmA8U1BOlQB5nvuKWuR+gpPXrz6B7ds+u9cE090auJK1dP7MiYMTlztx3yfdgQSCvdPO4E0BUNrQPFEORUR0nLKzfCy7B9u3pXbPPs7KPsq8a+m61s22fPzR60Y8kp3bcqSlnqirnjioNW8XcpILdxu2DyoxoAaYyatt3qdDXFOLIZ4Etm+bKGUrm9KrmmyL6Jqx67Y2UNAuAj71VJqS33aX+gfkYwAqU1B++ezpk+8MdUkthnqiyvZdYBRvfCLlBZNk6frCiVM1HRD5tjEpdefhcVvS+JaiuGA0BKDmMps3lt2r65SIDoloD8N5c/2ey861bVjX0t193wizePyJx6HWzr6t3ZzJzd6tn4fJn5y2r7x7zNZSFltRzQNQp7ln80ZTUg3bd4SRvOmOz4h2rm7OlFRTWRpnIO5STuzRToqdC1qD2TF715zt0y5zafVAzR9QL3M2bU4CUhWoPiMsQt5ou8fnTBSQN/WDE2ftWAvmAI00e6e9fVmWfJNmyXwdASj7DwL3ByIxoJZjCYzFGE968vrVnxDaEjbY7rUVU1n6VFPJtCiQfiaNBJBI0FLuXmBvYFeaUp1BcS0GLfgIfVhaQA3YC1XX0RDtBlPIpOzw7SUR7WNkbxSjmHPy+E5zLm/ify60FVj5Uuv7DWC24CZ0lnMgdC59IfK2HTiBZu9mkBBQiVsN6hzq07GuqcVYT9xoS1hiaG9UIOW0a3xjJzE/l22dc12dsOe4uPeSTz0p9wS3FwBLLQZrG2jtZpAyg0oMqBdj5FCTgBTyqU1WUtSCjQ9MrsZHZ+bk6oMqdW0Frs7x0pTy/lB2S4EUkDMtBtxjr783LUBd0gT6Gxdjv4DqAIczDO/NUlLNvia/qvLYp0g4iV3XpkyintYWzMqfWmqpCZHSsP9dw2lagFrSQMteJg+pClTfQZC+SUoqHkwt2xMLJ3vWjtxr7zTqyXUgJwsM22KWjsM8y7AFwgMAqg7KP5vCNXVvQtc3gvSNUVJyAO4NxJthuN142QzENWvwyPBNns2p+eZOm+TfGK8OxNlQ3Wo5ICJnQG7IiBvWuWbtBgDU8ZhB+SSVVCNIP0KQvglKSmflvKqpdOxQwCmn0lpvJ+VH9WOV4erJzsda9s5uObgtnTN49u6YZVnS7e3t2ArqIvWRVBsDqQpUn9Nq2QxANfNMygcmb9Yk/dwDJ9VBBw07FpI/2bN3HNSkE13YGbzSsAd0jgyok6ldUoupvaBqxu8Yo33eSsq77MSlmjzw6gTRwgku0rIT5yEHAiha4Tgze3db3vL5U8kspymNd7ZQAlTivcmbdUkTnWlfTPFFVTsmAFQzVlKcletsi6JUVfUSlg5cGrbOBSdu73LXWXSt1gcmHPfN3tmvZb0EJ2AGb2AFdUlEh1OYyZsNpCpQfQxQzVFJudVQkKqS1tcRvwOmr+cpVEG51FNnkXHZfr1Sg6ZPHfksX+KlLlRFK5MF1KQh1QDVGYb+3PweqfZo4lRVRzWVkXAqeTj5FJRXPXGBucLeNZe1aNUSADUDSFWg+g5hs7z5ZVJMxiTaOcayOXfULMtgOKkUlJVxtXKmxoyc1D3egqzH3tlAur29HQtQn039mlrM4cI/ef3qBKCaSyTVtXtSDtXKahyqybU8ZZ05eeDkzaA4lcSdiVda4XjJH7ipadDk7iftT76tgJoNpACq+ckp18Jgl51TK59Slzm5rJ5k7TqWzQaQrfo89k7KnzQ9UdsOqFlBCqCajZRiN3dzKSbO8nWgUMqHJvSCEzEzcqbk86iSyc8Us3c+GA3UYjBLQM0OUgDVTOwe1zIQASbR0pU6OLm2U7GtXUdV2TN3zGxeC5S3pdre+fInAGrmkAKoJu/0+M5wUoTkxr1o2DWzxymn1vdu+dzJ3t9JUk929sSpJ1ZhCXkTd5tM+dOsATVbSDVAdQwsTM/uraFEso0SgeJRTaLakr7XgFMrXxJyp+bP7D6t5lo8ST31adDMBKirOQNq1pCqQIWGz8kpKd2MmhSCh5zG4gSWBCfl8plm8yY7cyfsXtC0cj57lzl/Ilp1ku/PGVCzh5QFqiUQMQkh5Q2uRTB5VJNPRZVl6YeTveeTpm3AlJ2Qnutzsq0c972B8qcaUJNv1NTUvU0YGCevX318vntwSav9qHaAinG1lH3kUiuwInm/J/v20s9chyY0v+e6PdtcSnKzqetIq6aaCrGimewd0UR3M9haJdUA1We02ublEqAYU0l1Z+U6zZYOVSJZOTEgF2brvLsLcLlT2Q3G69uGNGL6AvKM+RMR0dkmAWqjIGWB6iVwMZqQWkOpViG35a2/zUABpo6lM/Jaut5wagTjHJi47MkGWW33BrJ3RKsdNb+zaZfUvU37haodPr95vntwTgjVR2DUas0bZ/c0Vs5p7xqWjtu+t7WtMAm2jqwz9crGtsDCUVn1axAPdmjul07UCcQHgNOSZj6DtzVKyoIVWhRGtnu+8Nynplyq6ba8ZZswO0tZbOVUmk5LwXoxcWlYa9cMwWM6xzMD6pI2YAZvKyFVgepjWh3ssAQ+hoIUBQPKB6bOHk3MkVAsuEp+T6ryltnDqZT7m6S2Ag5G9m0zZk9Eq4bmw2dPn3y+ydfUvU0fNCevX312vnuwR6sjsw6BkfyGT5rdkyzdercEku3c+j6eWTx2to7u9iW378fN+jUtW+xsXmY41fnTx9twRd3bhl+ykVN9RETPAZL8dk+VQdlgcoGHPO0HwtFWvuOpfLmTL4/ioJUZUFc0oTPxYPfSw+q7hNNoRrF77Ho4EnYL4HZLMO7Ob1eXuGtpimu3Ak0exW39m9ne7W8ToLZGSVmg+rSyfxe0OucPlcnuudSSrWLsmTmfnbNVU0cp1Rav0YgpKbEmXDQqiZvNy1xLIjrdFnu39ZBq2L//cL578GFl/3YAl0SIqtSNlC/5LF/HMmlPK3ac1yfBSYKQb73ggNaOaNXzd7zp4birigHe5EnX+e7Bg0pVHQIx/eunf/d9+he/+z6bIXEZkzTgQ1RT8+dSn5NWOYV8DFDPnz198t1tv6bubfsbUJ2a/E2oqlSZFNPMyaglp91zgKkFFk9Abt9HCyf79gNbO6JV79PxtmVPUFJQVYPUP/+db9BP/c439Hav/rkNJgZcLtXksnS+72tn+AYYK0tarb37Lq4kKCmfqnpMq/P+oKrCtVQbIkSsjesoowRg6gsnl9oaoLY+e4KSCldV9ytQHePd0NdP/vv36J/99ntuKFlNlq3vMWASraCwxk8LqInA6YpWM3ef4OoBpGJh9aiC1T7eDQ2kDugnv/0eq6CaaknKprRg8kFpBnAiWmWgZ5uwMR0gNQ1YwQJq8oNvH9C9b7/b2bHAVkus3VOCiQOQBkpc5jQSnGDtAKmsFvC0+gCsmPqJ33qX7v3Wux0wSHZPzKgCwNTX6g04Bi4ra/cprhRAKjesHlRSHXmVDanffIcWv/mObPcYtZQKTKx1nAacrmjV8/QxrhBACrAauRbf+lUqvvWrHcXEqSUOZBJ8tKpJq54GqiVt8XIWQAqwmmb9xtep+NbXVVDKDSaXhRwATmeEUByQAqwmWL/+K0S/8XU1lPpYvYlZurWtI6IXgBMgNRdYHdGWBezmm79M5td/hQWOBA/fbSaumtZwgq0DpOYIq3o28JiI9rbhdy6/+csrUBkTddhCnwCdU26Z62UFJ8zWAVIbAazHFawON/n3vD38Jbp99ItOm5fD7g1YS1ptRf0cfU6A1KbC6mGlrjbSCv740S/Sj9/fj7J7EwYT0arH6YyQNwFSUFfzrv///j79+P19lVKKsXsD15JWu2JcYNsUQGrbYfWgUlbHNPM1gv/4jV+gf/x3D/WnxCjs3gh1USkmLPoFpFCbBqx/+MYv0D/82s9HQWlkML2oP2DnACnUBgPr73/t5+nv3/s5pyJyzfINbOVeQDEBUqh0wLpfAeuw+tib4uv8u4Ofpb977+emCCWiVfhdgwkZEyCFygythw1gHdJEZgr/9t2v0d8e/OyUoPSy/oCNA6RQ40NrvwLW/lj28Efvfo1+9M7PjPHUywaULgElQAo1D3A9agBrjwZodfjROz9DP3r3a7mf5qr6qIF0icZKQAq1OeB60ADWTgWwnVTKKyGkamVU//eKiK6wBAWQQgFij6pPa3hRBbW9xs1EqDkgVcOmWTWEmp8vEWqjmvVPAwB1ib9CJko2MQAAAABJRU5ErkJggg==';
}

/***************************END IMAGE MANIPULATION FUNCTIONS**************************************/
/***************************END IMAGE MANIPULATION FUNCTIONS**************************************/