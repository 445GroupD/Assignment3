String.prototype.contains = function(it) { return this.indexOf(it) > -1}

function _id(id) {
	return document.getElementById(id);
}

Array.prototype.contains = function(obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
}