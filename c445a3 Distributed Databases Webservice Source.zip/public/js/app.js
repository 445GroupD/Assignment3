var app = angular.module("logsApp", ['ngRoute']);
//manipulate the "editorsApp" module of our app
app
    .config(['$routeProvider', '$locationProvider', function AppConfig($routeProvider, $locationProvider) {
        //the routeProvider module helps us configure routes in AngularJS.
        $routeProvider
            //when the user navigates to the root, index of our app
            .when("/", {
                //the url to the template for this view
                templateUrl: "views/logs-list.html",
                //the controller of this view
                controller: "LogsListController",
                //methods to retrieve content and do other things on load
                resolve: {
                    //get all of the editors
                    logs: function(Logs) {
                        return Logs.getLogs();
                    }
                }
            })
            //otherwise, default to sending them to the index page
            .otherwise({
                redirectTo: "/"
            });

        //NOT WORKING 042016 0251am $locationProvider.html5Mode({ enabled: true, requireBase: false });
        //# Use html5 mode.
        //$locationProvider.html5Mode(true)

    }])
        .filter('timeago', function() {
        return function(input, p_allowFuture) {
            var substitute = function (stringOrFunction, number, strings) {
                    var string = $.isFunction(stringOrFunction) ? stringOrFunction(number, dateDifference) : stringOrFunction;
                    var value = (strings.numbers && strings.numbers[number]) || number;
                    return string.replace(/%d/i, value);
                },
                nowTime = (new Date()).getTime(),
                date = (new Date(input)).getTime(),
                //refreshMillis= 6e4, //A minute
                allowFuture = p_allowFuture || false,
                strings= {
                    prefixAgo: null,
                    prefixFromNow: null,
                    suffixAgo: "",
                    suffixFromNow: "from now",
                    seconds: "less than 1 minute",
                    minute: "1 m",
                    minutes: "%d m",
                    hour: "1 h",
                    hours: "%d h",
                    day: "1 d",
                    days: "%d d",
                    month: "1 M",
                    months: "%d M",
                    year: "1 y",
                    years: "%d y"
                },
                dateDifference = nowTime - date,
                words,
                seconds = Math.abs(dateDifference) / 1000,
                minutes = seconds / 60,
                hours = minutes / 60,
                days = hours / 24,
                years = days / 365,
                separator = strings.wordSeparator === undefined ?  " " : strings.wordSeparator,
            
                // var strings = this.settings.strings;
                prefix = strings.prefixAgo,
                suffix = strings.suffixAgo;
                
            if (allowFuture) {
                if (dateDifference < 0) {
                    prefix = strings.prefixFromNow;
                    suffix = strings.suffixFromNow;
                }
            }

            words = seconds < 45 && substitute(strings.seconds, Math.round(seconds), strings) ||
            seconds < 90 && substitute(strings.minute, 1, strings) ||
            minutes < 45 && substitute(strings.minutes, Math.round(minutes), strings) ||
            minutes < 90 && substitute(strings.hour, 1, strings) ||
            hours < 24 && substitute(strings.hours, Math.round(hours), strings) ||
            hours < 42 && substitute(strings.day, 1, strings) ||
            days < 30 && substitute(strings.days, Math.round(days), strings) ||
            days < 45 && substitute(strings.month, 1, strings) ||
            days < 365 && substitute(strings.months, Math.round(days / 30), strings) ||
            years < 1.5 && substitute(strings.year, 1, strings) ||
            substitute(strings.years, Math.round(years), strings);

            return $.trim([prefix, words, suffix].join(separator));
            // conditional based on optional argument
            // if (somethingElse) {
            //     out = out.toUpperCase();
            // }
            // return out;
        }
    })
    /* An AngularJS service generates an object that can be used 
    by the rest of the application. Our service acts as the 
    client-side wrapper for all of our API endpoints.
    */
    //a service to run tasks for manipulating editors
    .service("Logs", function($http) {
        var functions = {};

        //gets all the logs that are being advertised
        this.getLogs = function() {
            NProgress.start();
            /*AS OF 042016, although we don't care if the user is logged in here, 
            if it is logged it, we want to send its id to the server for functional use*/

            //send REST request to our app to fetch all the editors
            return $http.get("/logs/all").
                //wait for response and then do something
                then(function(response) {
                    //action was successful
                    //console.log(JSON.stringify(response));
                    NProgress.done();
                    if(response) {
                        var responseDataLogs = response.data.logs;
                        console.log(responseDataLogs)
                        var logs = [];

                        function getServerLatestLog(serverLogs) {
                            //go from top to bottom
                            for(var i = serverLogs.length - 1; i >= 0; i--) {
                                if(serverLogs[i] && serverLogs[i].type && serverLogs[i].type.toLowerCase() === 'picture'){
                                    var latestServerLog = serverLogs[i];
                                    latestServerLog.isLatest = true;
                                    latestServerLog.numRelatives = serverLogs.length - 2;
                                    //latestServerLog.showEarlierLogs = true;

                                    logs.push(latestServerLog);
                                    logs[latestServerLog.serverId + "l"] = latestServerLog;
                                    return latestServerLog;
                                }
                            }
                            return;
                        }

                        for(var i = 0; i < responseDataLogs.length; i++) {
                            //get the current server's array of logs from the response data
                            var currentServerLogs = responseDataLogs[i];
                            if(currentServerLogs) {
                                //add each of the current server's logs to the array of all logs
                                var currentServerLatestLog = getServerLatestLog(currentServerLogs);
                                                            
                                if(currentServerLatestLog) {
                                    for (var j = 0; j < currentServerLogs.length; j++) {
                                        if(currentServerLogs[j]) {
                                            if(currentServerLogs[j].index != currentServerLatestLog.index){
                                                currentServerLogs[j].controllerLog = currentServerLatestLog;
                                                logs.push(currentServerLogs[j]);
                                            }
                                        } /*else {
                                            console.log("SPLICING AT " + j);
                                            //remove the element at j since it is invalid
                                            currentServerLogs.splice(j, 1);
                                            currentServerLatestLog.numRelatives--;
                                        }*/
                                    }
                                }
                                
                            }
                        }

                        console.log("NUM LOGS: " + logs.length);
                        //alert(logs)
                        response.data.logs = logs;
                    }
                    return response;
                }, function(response) {
                    //action failed
                    NProgress.done();
                    //alert("[getLogs] Error finding logs: " + JSON.stringify(response));
                });
        }

        this.getPub = function(pubId) {
            var url = "/logs/" + pubId;
            return $http.get(url).
                then(function (response) {
                    return response;
                }, function (response) {
                    alert("Error finding this pub.");
                });
        }
        
    })
    //a controller to display the data to appropriately list views 
    // allows us to add data to the scope and access it from our views.
    .controller("LogsListController", function($scope, $window, logs,  Logs) {
        $scope.heartbeats = [];
        $scope.refreshSecs = 120;
        $scope.clientLockedRefreshSecs = false;

        var originalLogs = logs.data.logs;
        if(originalLogs) {
            $scope.logs = originalLogs;
        } else $scope.logs = [];

        function refreshLogs() {
            if(!$scope.refreshingLogs) {
                $scope.refreshingLogs = true;
                Logs.getLogs().then(function (response) {
                    //console.log("FOUND new logs " + JSON.stringify(response))
                    if(response) {
                        var newLogs = response.data.logs;
                        var newRefreshSecs = response.data.refreshSecs;
                        if(newRefreshSecs && newRefreshSecs > 0) {
                            if(!$scope.clientLockedRefreshSecs) $scope.refreshSecs = newRefreshSecs;
                            console.log($scope.refreshSecs);
                        }

                        if(!originalLogs) $scope.logs = newLogs;
                        else {
                            //i want to add only the new ones, but for now, this will do
                            $scope.logs = newLogs;
                        }
                    }
                    $scope.refreshingLogs = false;
                    //refreshInterval = setInterval(refreshIntervalFunc, getRefreshSecs() * 1000);
                });
            }
        }

        $scope.refreshLogs = function() {
            refreshLogs();
        }

        $scope.showEarlierLogs = function(log) {
            log.showEarlierLogs = true;
        }

        $scope.hideEarlierLogs = function(log) {
            log.showEarlierLogs = false;
        }

        function getRefreshSecs() {
            return $scope.refreshSecs;
        }

        var refreshIntervalFunc = function(){
            clearInterval(refreshInterval);
            refreshLogs();
        }

        //var refreshInterval = setInterval(refreshIntervalFunc, getRefreshSecs() * 1000);
    });