<?php header('Access-Control-Allow-Origin: *'); ?><?php
	function sendEmail($from,$to,$subject,$body){
		$mail     = 'no-reply@'.str_replace('www.', '', $_SERVER['SERVER_NAME']);
		$uniqid   = md5(uniqid(time()));
		$headers  = 'From: Seen App <'.$mail.">\r\n";
		$headers .= 'Reply-to: '.$mail."\r\n";
		$headers .= 'Return-Path: '.$mail."\r\n";
		$headers .= 'Message-ID: <'.$uniqid.'@'.$_SERVER['SERVER_NAME'].">\r\n";
		$headers .= 'MIME-Version: 1.0'."\r\n";
		$headers .= 'Date: '.gmdate('D, d M Y H:i:s', time())."\r\n";
		$headers .= 'X-Priority: 3'."\r\n";
		$headers .= 'X-MSMail-Priority: Normal'."\r\n";
		$headers .= 'Content-type:text/html;charset=iso-8859-1'."\r\n";
		$headers .= 'Content-transfer-encoding: 7bit';
		//sends the email
		mail($to,$subject,$body,$headers); 
	}

	if(isset($_POST["type"] && isset($_POST["email"]) && isset($_POST["signinLink"])) {
		sendSuperMeditorLoginLink($_POST["email"], $_POST["signinLink"]);
		echo "success";
	}

	function sendSuperMeditorLoginLink($email, $sign_in_link) {
		$container_style = 'style="
		width: 600px;
	    margin-top: 0;
	    margin-right: auto;
	    margin-bottom: 0;
	    margin-left: auto;
	    padding-top: 40px;
	    padding-right: 20px;
	    padding-bottom: 40px;
	    padding-left: 10%;
	    color: #333332;
	    line-height: 1.4;
	    font-size: 16px;
	    font-weight: 300;
	    font-family: -apple-system,BlinkMacSystemFont,"Segoe UI","Roboto","Oxygen","Ubuntu","Cantarell","Open Sans","Helvetica Neue",sans-serif;
	    "';

		$buttonStyle = 'style="
	    color: #ffffff;
	    text-decoration: none;
	    display: inline-block;
	    min-height: 38px;
	    line-height: 38px;
	    padding-top: 0;
	    padding-right: 16px;
	    padding-bottom: 0;
	    padding-left: 16px;
	    border: 0;
	    outline: 0;
	    background-color: #02b875;
	    font-size: 14px;
	    font-style: normal;
	    font-weight: 400;
	    text-align: center;
	    white-space: nowrap;
	    border-radius: 999em;
	    "';

		$htmlEmailBody = '
		<div id="email-message" style="color:#b3b3b1;font-size:14px;text-align:center;margin-top:50px;margin-right:0;margin-bottom:50px;margin-left:0">
			<img src="lcontacts.herokuapp.com/img/logo_60.png"/>
			<br><br>
			<h1 style="color:#333332;">Your SuperMeditor Login Link is Below</h1>
			<p style="color:#b3b3b1; margin-top:0;margin-bottom:40px">
				Click and confirm that you want to login to SuperMeditor.<br>This link will expire when you log out.
			</p>
			
			<a href="'.$sign_in_link.'" '.$buttonStyle.'>Log in to SuperMeditor</a>
			<br><br>
			<p style="color:#333332;text-decoration:none; font-size:smaller"> 
				Or login by copy and pasting this link in your url bar
			</p>
			<a href="'.$sign_in_link.'" style="color:#333332;text-decoration:none">
				'.$sign_in_link.'
			</a>

			<div style="color:#b3b3b1;font-size:14px;text-align:center;margin-top:50px;margin-right:0;margin-bottom:50px;margin-left:0">
				If you did not make this request, you can ignore it.
			</div>

			<div style="padding-top:15px;padding-right:0;padding-bottom:0;padding-left:0;margin-top:50px;color:#b3b3b1;font-size:12px;text-align:center;border-top:1px solid #e5e5e5">Sent by Your Friends at 
				<a href="http://lcontacts.herokuapp.com" style="color:#b3b3b1;text-decoration:none" target="_blank">
					SuperMeditor
				</a> 
				· Shineman Center, 7060 NY-104, Oswego, NY 13126, USA
				<div>
					<a href="'.$host.'/policies" style="color:#b3b3b1;text-decoration:none" target="_blank">Terms & Conditions of Use</a> · <a href="'.$host.'/policies" style="color:#b3b3b1;text-decoration:none" target="_blank">Privacy policy
					</a>
				</div>
			</div>
	  </div>
	  ';

	  sendEmail("SuperMeditor@gmail.com",
	  	$ema
?>