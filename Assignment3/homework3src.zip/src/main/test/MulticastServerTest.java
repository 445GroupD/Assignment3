import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by dean on 4/20/16.
 */
public class MulticastServerTest
{

    @Before
    public void setUp() throws Exception
    {

    }

    @Test
    public void testStartServer() throws Exception
    {

    }
}